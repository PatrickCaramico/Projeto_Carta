# Projeto_Carta

Projeto Carta: é uma carta de apresentação online, desenvolvido em HTML e CSS. esse projeto foi desenvolvido com intuito de treinar meus domininos com linguagem de Marcação e linguagem em regras com o CSS. 

# Imagem do Projeto

<img aligh="center" src="imagem projeto/Tela Projeto.png" width="800px">

# Trecho do código

Trecho dos códigos em HTML e CSS; 

# 
HTML
<img aligh="center" src="imagem projeto/Tela HTML.png" width="800px">

#

#
CSS
<img aligh="center" src="imagem projeto/Tela CSS.png" width="800px">

#

# Link Projeto
**Link para acessar o projeto;**
https://patrickcaramico.github.io/Projeto_Carta/
